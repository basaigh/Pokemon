using System;
using System.Collections.Generic;
using System.Linq;
using EasyHttp.Http;

namespace PokemonCards
{
    public class Pokemon
    {
        public List<Data> allPokemon = new List<Data>();
        
        public void Initialise()
        {
            var http = new HttpClient();
            http.Request.Accept = HttpContentTypes.ApplicationJson;
            var response = http.Get("https://pokeapi.co/api/v2/pokemon?limit=100000&offset=0");
            var body = response.DynamicBody;
            this.allPokemon.Capacity = body.count;
            foreach (var entry in body.results)
            {
                this.allPokemon.Add(new Data(entry.name, entry.url));
            }

            this.allPokemon = this.allPokemon.OrderBy(entry => entry.Name).ToList();
        }
    }
    
    public class Data
    {
        public string Name { get; set; }
        public string Url { get; set; }
        public int HealthPoints { get; set; }
        public int Strength { get; set; }
        public string SpecialPower { get; set; }
        public string ImageUrl { get; set; }

        public Data(string name, string url)
        {
            this.Name = name;
            this.Url = url;
            this.HealthPoints = 0;
            this.Strength = 0;
            this.SpecialPower = "";
        }

        public void populate()
        {
            var http = new HttpClient();
            http.Request.Accept = HttpContentTypes.ApplicationJson;
            var response = http.Get(this.Url);
            var body = response.DynamicBody;
            this.HealthPoints = body.stats[0].base_stat;
            this.Strength = body.stats[1].base_stat;
            this.SpecialPower = body.abilities[0].ability.name;
            this.ImageUrl = body.sprites.other.home.front_default;
        }
    }
}