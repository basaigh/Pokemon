﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace PokemonCards
{
    public partial class Form1 : Form
    {
        private Pokemon pokemon;
        private static TextInfo textInfo = new CultureInfo("en-GB", false).TextInfo;
        private int index = 0;
        
        public Form1()
        {
            InitializeComponent();
            pokemon = new Pokemon();
            pokemon.Initialise();
            comboBox1.Items.AddRange(pokemon.allPokemon.Select(entry =>
            {
                string name = entry.Name.Replace('-', ' ');
                return textInfo.ToTitleCase(name);
            }).ToArray<object>());
            comboBox1.SelectedIndex = index;
            populateLabels();
        }

        void populateLabels()
        {
            pokemon.allPokemon[index].populate();
            this.label5.Text = pokemon.allPokemon[index].HealthPoints.ToString();
            this.label6.Text = pokemon.allPokemon[index].Strength.ToString();
            this.label7.Text = textInfo.ToTitleCase(pokemon.allPokemon[index].SpecialPower).Replace('-', ' ');
            this.pictureBox1.ImageLocation = pokemon.allPokemon[index].ImageUrl;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.index = comboBox1.SelectedIndex;
            populateLabels();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            throw new System.NotImplementedException();
        }
    }
}