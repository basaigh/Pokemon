using System.Windows.Forms;

namespace PokemonCards
{
    public partial class EditForm : Form
    {
        public EditForm()
        {
            InitializeComponent();
        }
    }
}